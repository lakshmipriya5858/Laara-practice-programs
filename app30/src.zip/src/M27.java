class M27 
{
	public static void main(String[] args) 
	{
		test.method1(new D());
		System.out.println("Hell !!!!!!");
	}
}
// original obj is D.dwncasting to C. hence run succflly.