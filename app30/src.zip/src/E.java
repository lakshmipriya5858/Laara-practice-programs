class E extends D 
{
	int m;
	void test5()
	{
		System.out.println("from E.test5()");
	}
}
/*
four class under one inheritance.
from sub class to super class==> auto casting.
from super to sub class==>down casting.
down casting is not done by the compiler itself.
derived casting is only for one inheritance class.
*/