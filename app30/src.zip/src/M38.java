class M38 
{
	public static void main(String[] args) 
	{
		A b1= new B();
		b1.test1();

		System.out.println(b1.i);
		b1.test2();
		System.out.println(b1.j);


	}
}
//cte
// compiler is searching for A and j (refrence type)