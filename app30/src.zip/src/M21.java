class M21
{
	public static void main(String[] args) 
	{
		B b1= new B();
		C c1 =  (C) b1;
          System.out.println("-------");
		D d1= (D)b1;
	System.out.println("-------");
// rte

	}
}
