class M23
{
	public static void main(String[] args) 
	{
		B b1= new D();
		C c1 =  (C) b1;
        System.out.println("-------");
		D d1= (D)b1;
	  System.out.println("-------");


	}
}


