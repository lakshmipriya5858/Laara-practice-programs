class M20 
{
	public static void main(String[] args) 
	{
		B b1= new B();
		C c1 = b1;
        System.out.println("-------");
		D d1= b1;
		System.out.println("-------");


	}
}
//cte
