class B extends A 
{
	int j;
	void test2()
	{
		System.out.println("from B.test2()");
	}
}
/*

*/