class M28
{
	public static void main(String[] args) 
	{
		test.method1(new B());
		System.out.println("done  !!!!!!");
	}
}
//rte. class casting xception