class M44
{
	public static void main(String[] args) 
	{
		A a1= new C(); //upcasting
		C c1= new C();
		System.out.println(a1.i);
		//System.out.println(a1.j);
		//System.out.println(a1.k);

		System.out.println(c1.i);
		System.out.println(c1.j);
		System.out.println(c1.k);
		
	}
}
