class A 
{
	int i;
	void test1()
	{
		System.out.println("from A.test1()");
	}
}
/*
CTE
*/