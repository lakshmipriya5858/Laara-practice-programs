class M24 
{
	public static void main(String[] args) 
	{
		Object obj = new D();
         A a1= obj;
       System.out.println("-----------");
	   B b1= obj;
	   System.out.println("-----------");

	    C c1= obj;
	 System.out.println("-----------");

		D d1 =obj;
		System.out.println("-----------");

		E e1= obj;
	 System.out.println("-----------");

	}
}
