class M34 
{
	public static void main(String[] args) 
	{
		test.method2(new A());
		System.out.println("------------");
		test.method2(new B());
		System.out.println("------------");
	   test.method2(new C());
		System.out.println("------------");
		test.method2(new D());
		System.out.println("------------");
		test.method2(new E());
		System.out.println("------------");
			test.method2("abc");
				System.out.println("------------");

	}
}
