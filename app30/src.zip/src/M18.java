class M18
{
	public static void main(String[] args) 
	{
		A a1 = new A();
		B b1= (B)a1;
		System.out.println("Hell");
	}
}
//run tym error.