class M42 
{
	public static void main(String[] args) 
	{
		B b1= new D();
		System.out.println(b1.i);
		System.out.println(b1.j);
		System.out.println(b1.k);
		System.out.println(b1.l);
	}
}
//cte
//
